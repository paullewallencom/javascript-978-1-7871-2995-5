/** Automatically generated file. DO NOT MODIFY */
package com.jsmobile.soundrecorder;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}