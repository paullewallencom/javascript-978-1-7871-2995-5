Sms Custom Cordova Plugin Client:
====================
This is a test Apache Cordova application for the Sms Custom Cordova Plugin which can be reached here:

[http://github.com/hazems/cordova-sms-plugin/](http://github.com/hazems/cordova-sms-plugin/)

